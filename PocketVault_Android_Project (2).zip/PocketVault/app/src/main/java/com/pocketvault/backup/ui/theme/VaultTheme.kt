package com.pocketvault.backup.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * Section 12 Color Palette — Premium Teal Cloud Vault
 */
object VaultColors {
    val DeepTealBg = Color(0xFF063C3D)
    val HeaderDarkSurface = Color(0xFF042F31)
    val SoftMint = Color(0xFFCFFFF0)
    val PaleMintSurface = Color(0xFFE4F7F1)
    val PrimaryTextOnLight = Color(0xFF123B38)
    val SecondaryText = Color(0xFF63817B)
    val SuccessAccent = Color(0xFF27AE83)
    val PureWhite = Color(0xFFFFFFFF)
    val WarningAmber = Color(0xFFD97706)
    val ErrorRed = Color(0xFFDC2626)
}

private val PocketVaultColorScheme = lightColorScheme(
    primary = VaultColors.DeepTealBg,
    onPrimary = VaultColors.PureWhite,
    primaryContainer = VaultColors.SoftMint,
    onPrimaryContainer = VaultColors.PrimaryTextOnLight,
    secondary = VaultColors.SuccessAccent,
    onSecondary = VaultColors.PureWhite,
    secondaryContainer = VaultColors.PaleMintSurface,
    onSecondaryContainer = VaultColors.PrimaryTextOnLight,
    background = VaultColors.PaleMintSurface,
    onBackground = VaultColors.PrimaryTextOnLight,
    surface = VaultColors.PureWhite,
    onSurface = VaultColors.PrimaryTextOnLight,
    surfaceVariant = VaultColors.PaleMintSurface,
    onSurfaceVariant = VaultColors.SecondaryText,
    error = VaultColors.ErrorRed,
    onError = VaultColors.PureWhite
)

val PocketVaultTypography = Typography(
    headlineLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 28.sp,
        lineHeight = 34.sp
    ),
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 22.sp,
        lineHeight = 28.sp
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 18.sp,
        lineHeight = 24.sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        lineHeight = 22.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        lineHeight = 22.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        lineHeight = 19.sp
    ),
    labelMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        lineHeight = 16.sp
    )
)

@Composable
fun PocketVaultTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = PocketVaultColorScheme,
        typography = PocketVaultTypography,
        content = content
    )
}
