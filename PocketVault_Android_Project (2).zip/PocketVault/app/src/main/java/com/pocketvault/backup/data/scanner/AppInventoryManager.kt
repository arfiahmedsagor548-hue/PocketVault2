package com.pocketvault.backup.data.scanner

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import com.pocketvault.backup.domain.model.InstalledAppRecord

/**
 * Generates an optional Installed App Inventory report with official Google Play Store links.
 * Explicitly separates user-installed apps from protected private app databases that Android
 * security prevents third-party apps from copying.
 */
class AppInventoryManager(private val context: Context) {

    fun collectInstalledAppInventory(includeSystemApps: Boolean = false): List<InstalledAppRecord> {
        val pm = context.packageManager
        val packages = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.getInstalledPackages(0)
        }

        val records = mutableListOf<InstalledAppRecord>()
        for (pkg in packages) {
            val appInfo = pkg.applicationInfo ?: continue
            val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            if (!includeSystemApps && isSystem) continue

            val label = pm.getApplicationLabel(appInfo).toString()
            val vCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                pkg.longVersionCode
            } else {
                @Suppress("DEPRECATION")
                pkg.versionCode.toLong()
            }

            records.add(
                InstalledAppRecord(
                    appName = label,
                    packageName = pkg.packageName,
                    versionName = pkg.versionName ?: "1.0",
                    versionCode = vCode,
                    playStoreUrl = "https://play.google.com/store/apps/details?id=${pkg.packageName}",
                    systemApp = isSystem
                )
            )
        }
        return records.sortedBy { it.appName.lowercase() }
    }
}
