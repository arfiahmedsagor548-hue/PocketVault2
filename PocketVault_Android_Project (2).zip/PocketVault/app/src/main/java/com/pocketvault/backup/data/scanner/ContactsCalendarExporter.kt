package com.pocketvault.backup.data.scanner

import android.content.ContentProviderOperation
import android.content.Context
import android.provider.CalendarContract
import android.provider.ContactsContract
import java.io.File

/**
 * Exports & imports Contacts (.vcf vCard 3.0) and Calendar Events (.ics iCalendar)
 * with duplicate detection on restore.
 */
class ContactsCalendarExporter(private val context: Context) {

    data class ContactRecord(
        val displayName: String,
        val phoneNumbers: List<String>,
        val emails: List<String>
    )

    fun exportContactsToVcf(outputFile: File): Int {
        val contacts = queryAllContacts()
        outputFile.bufferedWriter(Charsets.UTF_8).use { writer ->
            contacts.forEach { contact ->
                writer.appendLine("BEGIN:VCARD")
                writer.appendLine("VERSION:3.0")
                writer.appendLine("FN:${escapeVCard(contact.displayName)}")
                contact.phoneNumbers.forEach { phone ->
                    writer.appendLine("TEL;TYPE=CELL:${escapeVCard(phone)}")
                }
                contact.emails.forEach { email ->
                    writer.appendLine("EMAIL;TYPE=INTERNET:${escapeVCard(email)}")
                }
                writer.appendLine("END:VCARD")
            }
        }
        return contacts.size
    }

    fun importContactsFromVcf(
        vcfFile: File,
        skipDuplicates: Boolean = true
    ): RestoreContactsSummary {
        if (!vcfFile.exists()) return RestoreContactsSummary(0, 0, 0)
        val existingContacts = queryAllContacts()
        val existingSignatures = existingContacts.map {
            "${it.displayName.lowercase()}|${it.phoneNumbers.firstOrNull().orEmpty()}"
        }.toSet()

        val parsed = parseVcfFile(vcfFile)
        var imported = 0
        var skippedDuplicates = 0
        var failed = 0

        for (record in parsed) {
            val signature = "${record.displayName.lowercase()}|${record.phoneNumbers.firstOrNull().orEmpty()}"
            if (skipDuplicates && signature in existingSignatures) {
                skippedDuplicates++
                continue
            }
            val success = insertContactRecord(record)
            if (success) imported++ else failed++
        }
        return RestoreContactsSummary(imported, skippedDuplicates, failed)
    }

    fun exportCalendarToIcs(outputFile: File): Int {
        var exportedCount = 0
        outputFile.bufferedWriter(Charsets.UTF_8).use { writer ->
            writer.appendLine("BEGIN:VCALENDAR")
            writer.appendLine("VERSION:2.0")
            writer.appendLine("PRODID:-//PocketVault//Smart Backup & Restore//EN")

            val projection = arrayOf(
                CalendarContract.Events._ID,
                CalendarContract.Events.TITLE,
                CalendarContract.Events.DESCRIPTION,
                CalendarContract.Events.EVENT_LOCATION,
                CalendarContract.Events.DTSTART,
                CalendarContract.Events.DTEND
            )
            runCatching {
                context.contentResolver.query(
                    CalendarContract.Events.CONTENT_URI,
                    projection,
                    null, null, null
                )?.use { cursor ->
                    val idCol = cursor.getColumnIndexOrThrow(CalendarContract.Events._ID)
                    val titleCol = cursor.getColumnIndexOrThrow(CalendarContract.Events.TITLE)
                    val descCol = cursor.getColumnIndex(CalendarContract.Events.DESCRIPTION)
                    val locCol = cursor.getColumnIndex(CalendarContract.Events.EVENT_LOCATION)
                    val startCol = cursor.getColumnIndexOrThrow(CalendarContract.Events.DTSTART)
                    val endCol = cursor.getColumnIndex(CalendarContract.Events.DTEND)

                    while (cursor.moveToNext()) {
                        val uid = cursor.getLong(idCol)
                        val title = cursor.getString(titleCol) ?: "Untitled Event"
                        val desc = if (descCol >= 0) cursor.getString(descCol).orEmpty() else ""
                        val loc = if (locCol >= 0) cursor.getString(locCol).orEmpty() else ""
                        val dtStart = cursor.getLong(startCol)
                        val dtEnd = if (endCol >= 0) cursor.getLong(endCol) else dtStart + 3600_000L

                        writer.appendLine("BEGIN:VEVENT")
                        writer.appendLine("UID:pocketvault-$uid@local")
                        writer.appendLine("SUMMARY:${escapeVCard(title)}")
                        if (desc.isNotBlank()) writer.appendLine("DESCRIPTION:${escapeVCard(desc)}")
                        if (loc.isNotBlank()) writer.appendLine("LOCATION:${escapeVCard(loc)}")
                        writer.appendLine("DTSTART-EPOCH:$dtStart")
                        writer.appendLine("DTEND-EPOCH:$dtEnd")
                        writer.appendLine("END:VEVENT")
                        exportedCount++
                    }
                }
            }
            writer.appendLine("END:VCALENDAR")
        }
        return exportedCount
    }


    data class CalendarEventRecord(
        val uid: String,
        val summary: String,
        val description: String,
        val location: String,
        val dtStartEpoch: Long,
        val dtEndEpoch: Long
    )

    fun parseIcsFile(icsFile: File): List<CalendarEventRecord> {
        if (!icsFile.exists()) return emptyList()
        val events = mutableListOf<CalendarEventRecord>()
        var insideEvent = false
        var uid = ""
        var summary = ""
        var desc = ""
        var loc = ""
        var dtStart = System.currentTimeMillis()
        var dtEnd = dtStart + 3600_000L

        icsFile.forEachLine(Charsets.UTF_8) { raw ->
            val line = raw.trim()
            when {
                line.equals("BEGIN:VEVENT", ignoreCase = true) -> {
                    insideEvent = true
                    uid = ""
                    summary = ""
                    desc = ""
                    loc = ""
                }
                line.equals("END:VEVENT", ignoreCase = true) && insideEvent -> {
                    if (summary.isNotBlank()) {
                        events.add(
                            CalendarEventRecord(
                                uid = uid.ifBlank { "pv-${events.size}" },
                                summary = summary,
                                description = desc,
                                location = loc,
                                dtStartEpoch = dtStart,
                                dtEndEpoch = dtEnd
                            )
                        )
                    }
                    insideEvent = false
                }
                insideEvent && line.startsWith("UID:", ignoreCase = true) -> uid = line.substringAfter(":")
                insideEvent && line.startsWith("SUMMARY:", ignoreCase = true) -> summary = unescapeVCard(line.substringAfter(":"))
                insideEvent && line.startsWith("DESCRIPTION:", ignoreCase = true) -> desc = unescapeVCard(line.substringAfter(":"))
                insideEvent && line.startsWith("LOCATION:", ignoreCase = true) -> loc = unescapeVCard(line.substringAfter(":"))
                insideEvent && line.startsWith("DTSTART-EPOCH:", ignoreCase = true) -> {
                    dtStart = line.substringAfter(":").toLongOrNull() ?: dtStart
                }
                insideEvent && line.startsWith("DTEND-EPOCH:", ignoreCase = true) -> {
                    dtEnd = line.substringAfter(":").toLongOrNull() ?: (dtStart + 3600_000L)
                }
            }
        }
        return events
    }

    fun parseVcfFile(vcfFile: File): List<ContactRecord> {
        val records = mutableListOf<ContactRecord>()
        var currentName = ""
        val currentPhones = mutableListOf<String>()
        val currentEmails = mutableListOf<String>()
        var insideCard = false

        vcfFile.forEachLine(Charsets.UTF_8) { rawLine ->
            val line = rawLine.trim()
            when {
                line.equals("BEGIN:VCARD", ignoreCase = true) -> {
                    insideCard = true
                    currentName = ""
                    currentPhones.clear()
                    currentEmails.clear()
                }
                line.equals("END:VCARD", ignoreCase = true) && insideCard -> {
                    if (currentName.isNotBlank() || currentPhones.isNotEmpty()) {
                        records.add(
                            ContactRecord(
                                displayName = currentName.ifBlank { "Restored Contact" },
                                phoneNumbers = currentPhones.toList(),
                                emails = currentEmails.toList()
                            )
                        )
                    }
                    insideCard = false
                }
                insideCard && line.startsWith("FN:", ignoreCase = true) -> {
                    currentName = unescapeVCard(line.substringAfter(":"))
                }
                insideCard && line.startsWith("TEL", ignoreCase = true) -> {
                    val number = unescapeVCard(line.substringAfter(":"))
                    if (number.isNotBlank()) currentPhones.add(number)
                }
                insideCard && line.startsWith("EMAIL", ignoreCase = true) -> {
                    val email = unescapeVCard(line.substringAfter(":"))
                    if (email.isNotBlank()) currentEmails.add(email)
                }
            }
        }
        return records
    }

    private fun queryAllContacts(): List<ContactRecord> {
        val result = mutableListOf<ContactRecord>()
        val resolver = context.contentResolver
        runCatching {
            resolver.query(
                ContactsContract.Contacts.CONTENT_URI,
                arrayOf(ContactsContract.Contacts._ID, ContactsContract.Contacts.DISPLAY_NAME_PRIMARY),
                null, null, null
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(ContactsContract.Contacts._ID)
                val nameCol = cursor.getColumnIndexOrThrow(ContactsContract.Contacts.DISPLAY_NAME_PRIMARY)
                while (cursor.moveToNext()) {
                    val contactId = cursor.getString(idCol)
                    val displayName = cursor.getString(nameCol) ?: "Unnamed"
                    val phones = mutableListOf<String>()
                    val emails = mutableListOf<String>()

                    resolver.query(
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                        arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                        "${ContactsContract.CommonDataKinds.Phone.CONTACT_ID} = ?",
                        arrayOf(contactId),
                        null
                    )?.use { pCursor ->
                        val numCol = pCursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
                        while (pCursor.moveToNext()) {
                            pCursor.getString(numCol)?.let { phones.add(it) }
                        }
                    }

                    resolver.query(
                        ContactsContract.CommonDataKinds.Email.CONTENT_URI,
                        arrayOf(ContactsContract.CommonDataKinds.Email.ADDRESS),
                        "${ContactsContract.CommonDataKinds.Email.CONTACT_ID} = ?",
                        arrayOf(contactId),
                        null
                    )?.use { eCursor ->
                        val emailCol = eCursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Email.ADDRESS)
                        while (eCursor.moveToNext()) {
                            eCursor.getString(emailCol)?.let { emails.add(it) }
                        }
                    }

                    result.add(ContactRecord(displayName, phones, emails))
                }
            }
        }
        return result
    }

    private fun insertContactRecord(record: ContactRecord): Boolean {
        return runCatching {
            val ops = ArrayList<ContentProviderOperation>()
            ops.add(
                ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                    .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                    .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null)
                    .build()
            )
            ops.add(
                ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                    .withValue(
                        ContactsContract.Data.MIMETYPE,
                        ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE
                    )
                    .withValue(
                        ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME,
                        record.displayName
                    )
                    .build()
            )
            record.phoneNumbers.forEach { phone ->
                ops.add(
                    ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                        .withValue(
                            ContactsContract.Data.MIMETYPE,
                            ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE
                        )
                        .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, phone)
                        .withValue(
                            ContactsContract.CommonDataKinds.Phone.TYPE,
                            ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE
                        )
                        .build()
                )
            }
            record.emails.forEach { email ->
                ops.add(
                    ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                        .withValue(
                            ContactsContract.Data.MIMETYPE,
                            ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE
                        )
                        .withValue(ContactsContract.CommonDataKinds.Email.ADDRESS, email)
                        .build()
                )
            }
            context.contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
            true
        }.getOrDefault(false)
    }

    private fun escapeVCard(input: String): String =
        input.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")

    private fun unescapeVCard(input: String): String =
        input.replace("\\n", "\n").replace("\\,", ",").replace("\\;", ";").replace("\\\\", "\\")

    data class RestoreContactsSummary(
        val importedCount: Int,
        val skippedDuplicatesCount: Int,
        val failedCount: Int
    )
}
