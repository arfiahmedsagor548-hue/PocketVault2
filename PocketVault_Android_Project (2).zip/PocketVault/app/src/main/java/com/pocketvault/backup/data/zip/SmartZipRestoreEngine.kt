package com.pocketvault.backup.data.zip

import com.pocketvault.backup.data.security.ChecksumUtils
import com.pocketvault.backup.domain.model.ConflictResolutionStrategy
import com.pocketvault.backup.domain.model.ManifestFileRecord
import net.lingala.zip4j.ZipFile
import net.lingala.zip4j.exception.ZipException
import java.io.File
import java.io.FileOutputStream

/**
 * High-priority Restore & Verification Engine:
 * - Verifies archive SHA-256 checksum before extraction
 * - Blocks Zip-Slip path traversal attacks strictly
 * - Handles AES-256 password decryption and detects wrong passwords
 * - Verifies restored file-level SHA-256 checksums against BackupManifest
 * - Applies non-destructive conflict resolution (Keep Existing, Rename, Skip, Replace)
 */
class SmartZipRestoreEngine {

    data class ArchiveRestoreResult(
        val archiveName: String,
        val restoredFiles: List<File>,
        val skippedConflicts: List<String>,
        val checksumVerifiedCount: Int,
        val failedEntries: List<String>
    )

    fun verifyAndExtractArchive(
        archiveFile: File,
        expectedArchiveSha256: String?,
        destinationRootDir: File,
        expectedFileChecksums: Map<String, ManifestFileRecord> = emptyMap(),
        conflictStrategy: ConflictResolutionStrategy = ConflictResolutionStrategy.RENAME_RESTORED,
        userConfirmedReplace: Boolean = false,
        password: CharArray? = null,
        onEntryProgress: (entryName: String, index: Int, total: Int) -> Unit = { _, _, _ -> }
    ): ArchiveRestoreResult {
        if (!archiveFile.exists() || archiveFile.length() == 0L) {
            throw IllegalArgumentException("Archive file ${archiveFile.name} is missing or empty.")
        }

        // 1. Archive-level SHA-256 integrity check
        if (!expectedArchiveSha256.isNullOrBlank()) {
            val validArchiveHash = ChecksumUtils.verifyFileSha256(archiveFile, expectedArchiveSha256)
            if (!validArchiveHash) {
                throw SecurityException(
                    "Archive SHA-256 integrity mismatch for ${archiveFile.name}. Restoration halted to protect data."
                )
            }
        }

        val zipFile = ZipFile(archiveFile)
        if (! zipFile.isValidZipFile) {
            throw SecurityException("Archive ${archiveFile.name} is malformed or corrupted.")
        }

        if (zipFile.isEncrypted) {
            if (password == null || password.isEmpty()) {
                throw PasswordRequiredException("Archive ${archiveFile.name} is AES-256 encrypted. Password required.")
            }
            zipFile.setPassword(password)
        }

        destinationRootDir.mkdirs()
        val canonicalRootPath = destinationRootDir.canonicalPath + File.separator

        val headers = zipFile.fileHeaders
        val restoredFiles = mutableListOf<File>()
        val skippedConflicts = mutableListOf<String>()
        val failedEntries = mutableListOf<String>()
        var verifiedCount = 0

        headers.forEachIndexed { index, header ->
            if (header.isDirectory) return@forEachIndexed
            val entryName = header.fileName
            onEntryProgress(entryName, index + 1, headers.size)

            // 2. Strict Zip-Slip Path Traversal check
            val candidateFile = File(destinationRootDir, entryName)
            val canonicalCandidatePath = candidateFile.canonicalPath
            if (!canonicalCandidatePath.startsWith(canonicalRootPath)) {
                throw SecurityException(
                    "Rejected unsafe ZIP entry attempting path traversal outside destination: $entryName"
                )
            }

            // 3. Conflict resolution
            val finalTargetFile = if (candidateFile.exists()) {
                when (conflictStrategy) {
                    ConflictResolutionStrategy.KEEP_EXISTING,
                    ConflictResolutionStrategy.SKIP -> {
                        skippedConflicts.add(entryName)
                        return@forEachIndexed
                    }
                    ConflictResolutionStrategy.RENAME_RESTORED -> {
                        generateNonConflictingFile(candidateFile)
                    }
                    ConflictResolutionStrategy.REPLACE_CONFIRMED -> {
                        if (!userConfirmedReplace) {
                            skippedConflicts.add("$entryName (Skipped: replace not confirmed)")
                            return@forEachIndexed
                        }
                        candidateFile
                    }
                }
            } else {
                candidateFile
            }

            finalTargetFile.parentFile?.mkdirs()

            try {
                zipFile.getInputStream(header).use { zis ->
                    FileOutputStream(finalTargetFile).buffered(64 * 1024).use { fos ->
                        zis.copyTo(fos, 64 * 1024)
                    }
                }

                // 4. File-level SHA-256 verification against manifest
                val manifestEntry = expectedFileChecksums[entryName]
                if (manifestEntry != null && manifestEntry.sha256Checksum.isNotBlank()) {
                    val fileValid = ChecksumUtils.verifyFileSha256(finalTargetFile, manifestEntry.sha256Checksum)
                    if (!fileValid) {
                        finalTargetFile.delete()
                        failedEntries.add("$entryName (File SHA-256 mismatch)")
                        return@forEachIndexed
                    }
                    verifiedCount++
                } else {
                    verifiedCount++
                }

                restoredFiles.add(finalTargetFile)
            } catch (ze: ZipException) {
                finalTargetFile.delete()
                if (ze.type == ZipException.Type.WRONG_PASSWORD ||
                    ze.message?.contains("Wrong password", ignoreCase = true) == true
                ) {
                    throw WrongPasswordException("Incorrect decryption password for ${archiveFile.name}.")
                }
                failedEntries.add("$entryName (${ze.message ?: "ZIP extraction failure"})")
            } catch (e: Exception) {
                finalTargetFile.delete()
                failedEntries.add("$entryName (${e.message ?: "Extraction error"})")
            }
        }

        return ArchiveRestoreResult(
            archiveName = archiveFile.name,
            restoredFiles = restoredFiles,
            skippedConflicts = skippedConflicts,
            checksumVerifiedCount = verifiedCount,
            failedEntries = failedEntries
        )
    }

    private fun generateNonConflictingFile(original: File): File {
        val parent = original.parentFile ?: File(".")
        val baseName = original.nameWithoutExtension
        val ext = original.extension.let { if (it.isNotEmpty()) ".$it" else "" }
        var counter = 1
        var candidate = File(parent, "${baseName}_restored_$counter$ext")
        while (candidate.exists()) {
            counter++
            candidate = File(parent, "${baseName}_restored_$counter$ext")
        }
        return candidate
    }

    class PasswordRequiredException(message: String) : Exception(message)
    class WrongPasswordException(message: String) : Exception(message)
}
