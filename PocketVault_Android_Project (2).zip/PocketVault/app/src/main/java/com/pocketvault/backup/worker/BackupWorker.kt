package com.pocketvault.backup.worker

import android.content.Context
import android.os.Build
import androidx.work.*
import com.pocketvault.backup.data.drive.GoogleDriveRepository
import com.pocketvault.backup.data.local.BackupSnapshotEntity
import com.pocketvault.backup.data.local.OperationLogEntity
import com.pocketvault.backup.data.local.PocketVaultDatabase
import com.pocketvault.backup.data.scanner.MobileStorageScanner
import com.pocketvault.backup.data.security.VaultSecurityManager
import com.pocketvault.backup.data.zip.BackupReportGenerator
import com.pocketvault.backup.data.zip.SmartZipBackupEngine
import com.pocketvault.backup.domain.model.BackupConfiguration
import com.pocketvault.backup.domain.model.BackupManifest
import com.pocketvault.backup.domain.model.BackupMode
import com.pocketvault.backup.domain.model.ManifestArchiveRecord
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit

/**
 * Step 4 Background Worker — Executes scheduled incremental backups via WorkManager
 * while respecting Wi-Fi Only (NetworkType.UNMETERED) and Charging Only constraints.
 */
class BackupWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        val db = PocketVaultDatabase.getInstance(applicationContext)
        val dao = db.dao()
        val securityManager = VaultSecurityManager(applicationContext)
        val driveRepo = GoogleDriveRepository(applicationContext, securityManager)
        val scanner = MobileStorageScanner(applicationContext)
        val zipEngine = SmartZipBackupEngine(applicationContext, dao)

        return try {
            setProgress(workDataOf("status" to "SCANNING_STORAGE"))
            val categories = scanner.scanAllAccessibleCategories()
            val eligible = categories.filter { it.isSelected && it.files.isNotEmpty() }
            if (eligible.isEmpty()) {
                return Result.success(workDataOf("status" to "NO_ELIGIBLE_CHANGES"))
            }

            val timestamp = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date())
            val backupId = "PV-SCHED-$timestamp-${UUID.randomUUID().toString().take(4)}"
            val deviceLabel = "${Build.MANUFACTURER}_${Build.MODEL}".replace(" ", "_")
            val stagingDir = File(applicationContext.cacheDir, "sched_$backupId").apply { mkdirs() }
            val config = BackupConfiguration(mode = BackupMode.INCREMENTAL)

            val signedIn = driveRepo.getSignedInAccount()
            val remoteFolderId = if (signedIn != null) {
                val rootId = driveRepo.ensureRootBackupFolder()
                val devId = driveRepo.ensureSubFolder(rootId, deviceLabel)
                driveRepo.ensureSubFolder(devId, timestamp)
            } else {
                "LOCAL_SCHEDULED_ONLY"
            }

            val archiveRecords = mutableListOf<ManifestArchiveRecord>()
            val fileRecords = mutableListOf<com.pocketvault.backup.domain.model.ManifestFileRecord>()
            val skippedRecords = mutableListOf<com.pocketvault.backup.domain.model.SkippedFileRecord>()

            for (summary in eligible) {
                val res = zipEngine.createCategoryArchives(
                    backupId = backupId,
                    category = summary.category,
                    files = summary.files,
                    stagingDir = stagingDir,
                    config = config
                ) { completed, fileName, _ ->
                    setProgress(workDataOf("category" to summary.category.id, "file" to fileName, "done" to completed))
                }
                fileRecords.addAll(res.manifestFileRecords)
                skippedRecords.addAll(res.skippedFiles)
                dao.upsertCachedFiles(res.updatedCacheEntries)

                for (part in res.generatedArchives) {
                    val driveId = if (signedIn != null) {
                        driveRepo.uploadFileResumable(remoteFolderId, part.archiveFile, "application/zip")
                    } else "LOCAL_${part.archiveFile.name}"
                    archiveRecords.add(
                        ManifestArchiveRecord(
                            archiveName = part.archiveFile.name,
                            categoryId = summary.category.id,
                            partIndex = part.partIndex,
                            sizeBytes = part.sizeBytes,
                            sha256Checksum = part.sha256Checksum,
                            driveFileId = driveId,
                            encryptedAes256 = false,
                            verified = true
                        )
                    )
                    if (signedIn != null) part.archiveFile.delete()
                }
            }

            val manifest = BackupManifest(
                backupId = backupId,
                deviceLabel = deviceLabel,
                androidSdkInt = Build.VERSION.SDK_INT,
                androidRelease = Build.VERSION.RELEASE ?: "14",
                createdAtIso = timestamp,
                createdAtEpochMillis = System.currentTimeMillis(),
                backupMode = BackupMode.INCREMENTAL.name,
                encryptedAes256 = false,
                selectedCategories = eligible.map { it.category.id },
                categoryStatuses = eligible.associate { it.category.id to "PROTECTED" },
                totalFilesCount = fileRecords.size,
                totalRawBytes = fileRecords.sumOf { it.sizeBytes },
                totalArchiveBytes = archiveRecords.sumOf { it.sizeBytes },
                archives = archiveRecords,
                files = fileRecords,
                skippedFiles = skippedRecords
            )

            val manifestFile = File(stagingDir, "backup_manifest.json")
            val json = BackupReportGenerator.writeManifestJson(manifest, manifestFile)
            val manifestDriveId = if (signedIn != null) {
                driveRepo.uploadFileResumable(remoteFolderId, manifestFile, "application/json")
            } else "LOCAL_MANIFEST"

            dao.insertSnapshot(
                BackupSnapshotEntity(
                    backupId = backupId,
                    deviceLabel = deviceLabel,
                    createdAtEpochMillis = manifest.createdAtEpochMillis,
                    createdAtFormatted = timestamp,
                    categoriesCsv = manifest.selectedCategories.joinToString(", "),
                    totalFilesCount = manifest.totalFilesCount,
                    totalArchiveSizeBytes = manifest.totalArchiveBytes,
                    driveFolderId = remoteFolderId,
                    manifestDriveFileId = manifestDriveId,
                    encryptedAes256 = false,
                    verificationStatus = "VERIFIED",
                    manifestJson = json,
                    reportHtmlPath = null
                )
            )

            dao.insertLog(
                OperationLogEntity(
                    timestampMillis = System.currentTimeMillis(),
                    operationType = "SCHEDULED_BACKUP",
                    severity = "INFO",
                    title = "Scheduled Incremental Backup Completed",
                    details = "Snapshot $backupId archived ${fileRecords.size} changed files and skipped ${skippedRecords.size} unchanged items.",
                    suggestedAction = "No action required."
                )
            )

            Result.success(workDataOf("backup_id" to backupId))
        } catch (e: Exception) {
            if (runAttemptCount < 3) Result.retry() else Result.failure(
                workDataOf("error" to (e.message ?: "Scheduled backup failed"))
            )
        }
    }

    companion object {
        private const val UNIQUE_PERIODIC_WORK_NAME = "pocketvault_scheduled_backup"

        fun schedulePeriodicBackup(
            context: Context,
            intervalHours: Long,
            wifiOnly: Boolean,
            chargingOnly: Boolean
        ) {
            if (intervalHours <= 0L) {
                WorkManager.getInstance(context).cancelUniqueWork(UNIQUE_PERIODIC_WORK_NAME)
                return
            }
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(if (wifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED)
                .setRequiresCharging(chargingOnly)
                .setRequiresStorageNotLow(true)
                .build()

            val request = PeriodicWorkRequestBuilder<BackupWorker>(intervalHours, TimeUnit.HOURS)
                .setConstraints(constraints)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 15, TimeUnit.MINUTES)
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                UNIQUE_PERIODIC_WORK_NAME,
                ExistingPeriodicWorkPolicy.UPDATE,
                request
            )
        }
    }
}
