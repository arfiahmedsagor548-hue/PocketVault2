package com.pocketvault.backup.domain.model

import kotlinx.serialization.Serializable

enum class BackupCategory(
    val id: String,
    val titleEn: String,
    val titleBn: String,
    val zipPrefix: String,
    val defaultRestoreSubpath: String,
    val requiresRuntimePermission: Boolean = true
) {
    PHOTOS("photos", "Photos & Images", "ছবি ও ইমেজ", "Photos", "Pictures/PocketVault"),
    VIDEOS("videos", "Videos", "ভিডিও", "Videos", "Movies/PocketVault"),
    SCREENSHOTS("screenshots", "Screenshots", "স্ক্রিনশট", "Screenshots", "Pictures/PocketVault/Screenshots"),
    AUDIO("audio", "Audio & Music", "অডিও ও মিউজিক", "Audio", "Music/PocketVault"),
    VOICE_RECORDINGS("voice_recordings", "Voice Recordings", "ভয়েস রেকর্ডিং", "VoiceRecordings", "Music/PocketVault/Recordings"),
    DOCUMENTS("documents", "Documents", "ডকুমেন্টস (PDF, Office, TXT)", "Documents", "Documents/PocketVault"),
    DOWNLOADS("downloads", "Downloads", "ডাউনলোডস", "Downloads", "Download/PocketVault"),
    OTHER_FILES("other_files", "Other Files", "অন্যান্য ফাইল", "OtherFiles", "Documents/PocketVault/Other Files"),
    USER_FOLDERS("user_folders", "User-Selected Folders", "নির্বাচিত ফোল্ডার", "SelectedFolders", "Documents/PocketVault/SelectedFolders", false),
    CONTACTS("contacts", "Contacts (.vcf)", "কন্টাক্টস (.vcf)", "Contacts", "Documents/PocketVault/Contacts"),
    CALENDAR("calendar", "Calendar Events (.ics)", "ক্যালেন্ডার ইভেন্ট (.ics)", "Calendar", "Documents/PocketVault/Calendar"),
    SMS_CALL_LOGS("sms_calls", "SMS & Call Logs (Policy-gated)", "এসএমএস ও কল লগ (নীতিমালা সাপেক্ষে)", "Communications", "Documents/PocketVault/Communications")
}

enum class CategoryBackupStatus {
    NOT_BACKED_UP,
    READY,
    BACKING_UP,
    PROTECTED,
    ACTION_REQUIRED,
    PERMISSION_LIMITED
}

enum class BackupMode(val labelEn: String, val labelBn: String) {
    FULL("Full Backup", "সম্পূর্ণ ব্যাকআপ"),
    CATEGORY("Category Backup", "ক্যাটাগরি ভিত্তিক ব্যাকআপ"),
    INCREMENTAL("Incremental Backup", "ইনক্রিমেন্টাল ব্যাকআপ (পরিবর্তিত ফাইল)"),
    SCHEDULED("Scheduled Backup", "নির্ধারিত স্বয়ংক্রিয় ব্যাকআপ"),
    MANUAL("Manual Immediate Backup", "ম্যানুয়াল তাৎক্ষণিক ব্যাকআপ")
}

enum class ScheduleFrequency(val labelEn: String, val hoursInterval: Long) {
    MANUAL_ONLY("Manual Only", 0L),
    DAILY("Daily (Every 24 Hours)", 24L),
    WEEKLY("Weekly (Every 7 Days)", 168L)
}

enum class ConflictResolutionStrategy(val labelEn: String, val descriptionEn: String) {
    KEEP_EXISTING("Keep Existing", "Do not overwrite existing files; skip conflicting items safely."),
    RENAME_RESTORED("Rename Restored Copy", "Save restored file with a numbered suffix (e.g., photo_restored_1.jpg)."),
    SKIP("Skip File", "Record conflict in restoration report and leave local file untouched."),
    REPLACE_CONFIRMED("Replace After Confirmation", "Overwrite existing target file only after explicit user confirmation.")
}

data class ScannedFileItem(
    val id: String,
    val contentUriString: String,
    val displayName: String,
    val relativePath: String,
    val mimeType: String,
    val sizeBytes: Long,
    val lastModifiedEpochMillis: Long,
    val category: BackupCategory,
    val selected: Boolean = true,
    val sha256Checksum: String? = null
)

data class CategoryScanSummary(
    val category: BackupCategory,
    val totalItemCount: Int,
    val totalSizeBytes: Long,
    val estimatedBackupSizeBytes: Long,
    val lastModifiedMillis: Long?,
    val isSelected: Boolean,
    val status: CategoryBackupStatus,
    val permissionGranted: Boolean,
    val limitationNote: String? = null,
    val files: List<ScannedFileItem> = emptyList()
)

data class BackupConfiguration(
    val mode: BackupMode = BackupMode.FULL,
    val maxArchivePartSizeBytes: Long = 1024L * 1024L * 1024L,
    val encryptArchives: Boolean = false,
    val wifiOnly: Boolean = true,
    val chargingOnly: Boolean = false,
    val scheduleFrequency: ScheduleFrequency = ScheduleFrequency.MANUAL_ONLY,
    val includeAppInventory: Boolean = true
)

@Serializable
data class ManifestFileRecord(
    val relativePath: String,
    val fileName: String,
    val categoryId: String,
    val mimeType: String,
    val sizeBytes: Long,
    val lastModifiedEpochMillis: Long,
    val sha256Checksum: String,
    val archivePartName: String
)

@Serializable
data class ManifestArchiveRecord(
    val archiveName: String,
    val categoryId: String,
    val partIndex: Int,
    val sizeBytes: Long,
    val sha256Checksum: String,
    val driveFileId: String,
    val encryptedAes256: Boolean,
    val verified: Boolean
)

@Serializable
data class SkippedFileRecord(
    val relativePath: String,
    val categoryId: String,
    val reason: String
)

@Serializable
data class InstalledAppRecord(
    val appName: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val playStoreUrl: String,
    val systemApp: Boolean
)

@Serializable
data class BackupManifest(
    val backupId: String,
    val formatVersion: Int = 1,
    val deviceLabel: String,
    val androidSdkInt: Int,
    val androidRelease: String,
    val createdAtIso: String,
    val createdAtEpochMillis: Long,
    val backupMode: String,
    val encryptedAes256: Boolean,
    val selectedCategories: List<String>,
    val categoryStatuses: Map<String, String>,
    val totalFilesCount: Int,
    val totalRawBytes: Long,
    val totalArchiveBytes: Long,
    val archives: List<ManifestArchiveRecord>,
    val files: List<ManifestFileRecord>,
    val skippedFiles: List<SkippedFileRecord>,
    val appInventory: List<InstalledAppRecord> = emptyList(),
    val restorationNotes: List<String> = emptyList()
)

data class ActiveTransferProgress(
    val isRunning: Boolean = false,
    val isPaused: Boolean = false,
    val isRestoreOperation: Boolean = false,
    val currentPhaseTitle: String = "Idle",
    val currentCategory: String = "",
    val currentFileName: String = "",
    val overallFraction: Float = 0f,
    val completedFiles: Int = 0,
    val totalFiles: Int = 0,
    val processedBytes: Long = 0L,
    val totalEstimatedBytes: Long = 0L,
    val transferSpeedBytesPerSec: Long = 0L,
    val estimatedRemainingSeconds: Long? = null,
    val warnings: List<String> = emptyList(),
    val failedItems: List<String> = emptyList()
)
