package com.pocketvault.backup.data.drive

import android.content.Context
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.Scope
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential
import com.google.api.client.googleapis.media.MediaHttpUploader
import com.google.api.client.http.FileContent
import com.google.api.client.http.javanet.NetHttpTransport
import com.google.api.client.json.gson.GsonFactory
import com.google.api.services.drive.Drive
import com.google.api.services.drive.DriveScopes
import com.pocketvault.backup.data.security.VaultSecurityManager
import com.pocketvault.backup.data.zip.BackupReportGenerator
import com.pocketvault.backup.domain.model.BackupManifest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import com.google.api.services.drive.model.File as DriveFile

/**
 * Direct-to-Google-Drive API v3 client using minimum scope (DriveScopes.DRIVE_FILE).
 * - Never accesses unrelated user files
 * - Deduplicates root "PocketVault Backups" folder before creating
 * - Organizes into PocketVault Backups / <Device_Name> / <yyyy-MM-dd_HH-mm-ss> /
 * - Uses resumable media upload sessions for large ZIP parts
 * - Discovers snapshots across devices after factory reset without needing local folder IDs
 */
class GoogleDriveRepository(
    private val context: Context,
    private val securityManager: VaultSecurityManager
) {
    companion object {
        const val ROOT_BACKUP_FOLDER_NAME = "PocketVault Backups"
        private const val FOLDER_MIME_TYPE = "application/vnd.google-apps.folder"
        private const val CHUNK_SIZE_BYTES = 5 * 1024 * 1024 // 5 MB resumable chunks
    }

    data class DriveQuotaSummary(
        val limitBytes: Long,
        val usageBytes: Long,
        val availableBytes: Long
    )

    data class RemoteSnapshotInfo(
        val snapshotFolderId: String,
        val snapshotFolderName: String,
        val deviceFolderName: String,
        val manifestFileId: String,
        val manifest: BackupManifest
    )

    fun buildGoogleSignInClient(): GoogleSignInClient {
        val signInOptions = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestScopes(Scope(DriveScopes.DRIVE_FILE))
            .build()
        return GoogleSignIn.getClient(context, signInOptions)
    }

    fun getSignedInAccount(): GoogleSignInAccount? {
        val account = GoogleSignIn.getLastSignedInAccount(context)
        if (account != null && GoogleSignIn.hasPermissions(account, Scope(DriveScopes.DRIVE_FILE))) {
            securityManager.connectedAccountEmail = account.email
            return account
        }
        return null
    }

    private fun buildDriveService(): Drive {
        val account = getSignedInAccount()
            ?: throw IllegalStateException("Google Drive account is not connected or authorization expired.")
        val credential = GoogleAccountCredential.usingOAuth2(
            context,
            listOf(DriveScopes.DRIVE_FILE)
        ).apply {
            selectedAccount = account.account
        }
        return Drive.Builder(
            NetHttpTransport(),
            GsonFactory.getDefaultInstance(),
            credential
        ).setApplicationName("PocketVault").build()
    }

    suspend fun fetchStorageQuota(): DriveQuotaSummary? = withContext(Dispatchers.IO) {
        runCatching {
            val drive = buildDriveService()
            val about = drive.about().get().setFields("storageQuota").execute()
            val quota = about.storageQuota ?: return@runCatching null
            val limit = quota.limit ?: 15L * 1024L * 1024L * 1024L
            val usage = quota.usage ?: 0L
            DriveQuotaSummary(
                limitBytes = limit,
                usageBytes = usage,
                availableBytes = (limit - usage).coerceAtLeast(0L)
            )
        }.getOrNull()
    }

    /**
     * Checks whether the root "PocketVault Backups" folder already exists in Drive
     * before creating a new one, preventing duplicate folders even after a phone reset.
     */
    suspend fun ensureRootBackupFolder(): String = withContext(Dispatchers.IO) {
        val drive = buildDriveService()
        val cachedId = securityManager.driveRootFolderId
        if (!cachedId.isNullOrBlank()) {
            val existing = runCatching {
                drive.files().get(cachedId).setFields("id, name, trashed").execute()
            }.getOrNull()
            if (existing != null && existing.trashed != true) {
                return@withContext existing.id
            }
        }

        val query = "mimeType = '$FOLDER_MIME_TYPE' and name = '$ROOT_BACKUP_FOLDER_NAME' and trashed = false"
        val result = drive.files().list()
            .setQ(query)
            .setSpaces("drive")
            .setFields("files(id, name, createdTime)")
            .execute()

        val found = result.files?.firstOrNull()
        if (found != null) {
            securityManager.driveRootFolderId = found.id
            return@withContext found.id
        }

        val metadata = DriveFile().apply {
            name = ROOT_BACKUP_FOLDER_NAME
            mimeType = FOLDER_MIME_TYPE
        }
        val created = drive.files().create(metadata).setFields("id").execute()
        securityManager.driveRootFolderId = created.id
        created.id
    }

    suspend fun ensureSubFolder(parentFolderId: String, folderName: String): String = withContext(Dispatchers.IO) {
        val drive = buildDriveService()
        val escapedName = folderName.replace("'", "\\'")
        val query = "mimeType = '$FOLDER_MIME_TYPE' and '$parentFolderId' in parents and name = '$escapedName' and trashed = false"
        val existing = drive.files().list()
            .setQ(query)
            .setSpaces("drive")
            .setFields("files(id, name)")
            .execute()
            .files
            ?.firstOrNull()

        if (existing != null) return@withContext existing.id

        val metadata = DriveFile().apply {
            name = folderName
            mimeType = FOLDER_MIME_TYPE
            parents = listOf(parentFolderId)
        }
        drive.files().create(metadata).setFields("id").execute().id
    }

    /**
     * Uploads an archive or manifest file using Drive API v3 Resumable Upload sessions.
     */
    suspend fun uploadFileResumable(
        parentFolderId: String,
        localFile: File,
        mimeType: String,
        onUploadProgress: (uploadedBytes: Long, totalBytes: Long) -> Unit = { _, _ -> }
    ): String = withContext(Dispatchers.IO) {
        val drive = buildDriveService()
        val fileMetadata = DriveFile().apply {
            name = localFile.name
            parents = listOf(parentFolderId)
        }
        val mediaContent = FileContent(mimeType, localFile)
        val createRequest = drive.files().create(fileMetadata, mediaContent)
            .setFields("id, name, size, md5Checksum")

        createRequest.mediaHttpUploader?.apply {
            isDirectUploadEnabled = false // Use Resumable Upload protocol
            chunkSize = CHUNK_SIZE_BYTES
            setProgressListener { uploader ->
                when (uploader.uploadState) {
                    MediaHttpUploader.UploadState.MEDIA_IN_PROGRESS -> {
                        onUploadProgress(uploader.numBytesUploaded, localFile.length())
                    }
                    MediaHttpUploader.UploadState.MEDIA_COMPLETE -> {
                        onUploadProgress(localFile.length(), localFile.length())
                    }
                    else -> Unit
                }
            }
        }

        val uploaded = createRequest.execute()
        uploaded.id
    }

    /**
     * Discovers all remote backup snapshots across all device folders inside "PocketVault Backups"
     * after a factory reset or on a replacement phone without requiring local database state.
     */
    suspend fun discoverRemoteSnapshots(): List<RemoteSnapshotInfo> = withContext(Dispatchers.IO) {
        val drive = buildDriveService()
        val rootId = ensureRootBackupFolder()
        val snapshots = mutableListOf<RemoteSnapshotInfo>()

        // List Device folders under PocketVault Backups
        val deviceFolders = drive.files().list()
            .setQ("mimeType = '$FOLDER_MIME_TYPE' and '$rootId' in parents and trashed = false")
            .setFields("files(id, name)")
            .execute()
            .files.orEmpty()

        for (deviceFolder in deviceFolders) {
            val timestampFolders = drive.files().list()
                .setQ("mimeType = '$FOLDER_MIME_TYPE' and '${deviceFolder.id}' in parents and trashed = false")
                .setFields("files(id, name, createdTime)")
                .execute()
                .files.orEmpty()

            for (snapFolder in timestampFolders) {
                val manifestFiles = drive.files().list()
                    .setQ("'${snapFolder.id}' in parents and name = 'backup_manifest.json' and trashed = false")
                    .setFields("files(id, name)")
                    .execute()
                    .files.orEmpty()

                val manifestFile = manifestFiles.firstOrNull() ?: continue
                runCatching {
                    val out = ByteArrayOutputStream()
                    drive.files().get(manifestFile.id).executeMediaAndDownloadTo(out)
                    val jsonStr = out.toString("UTF-8")
                    val manifest = BackupReportGenerator.parseManifestJson(jsonStr)
                    snapshots.add(
                        RemoteSnapshotInfo(
                            snapshotFolderId = snapFolder.id,
                            snapshotFolderName = snapFolder.name,
                            deviceFolderName = deviceFolder.name,
                            manifestFileId = manifestFile.id,
                            manifest = manifest
                        )
                    )
                }
            }
        }
        snapshots.sortedByDescending { it.manifest.createdAtEpochMillis }
    }

    suspend fun downloadDriveFile(
        driveFileId: String,
        destinationFile: File,
        expectedSizeBytes: Long,
        onDownloadProgress: (downloadedBytes: Long, totalBytes: Long) -> Unit = { _, _ -> }
    ): File = withContext(Dispatchers.IO) {
        val drive = buildDriveService()
        destinationFile.parentFile?.mkdirs()
        val getRequest = drive.files().get(driveFileId)
        getRequest.mediaHttpDownloader?.apply {
            isDirectDownloadEnabled = false
            chunkSize = CHUNK_SIZE_BYTES
            setProgressListener { downloader ->
                onDownloadProgress(downloader.numBytesDownloaded, expectedSizeBytes)
            }
        }
        FileOutputStream(destinationFile).use { fos ->
            getRequest.executeMediaAndDownloadTo(fos)
        }
        destinationFile
    }
}
