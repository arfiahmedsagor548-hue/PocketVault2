package com.pocketvault.backup.data.scanner

import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import com.pocketvault.backup.domain.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Scans accessible device files using Android MediaStore, Storage Access Framework (SAF),
 * ContactsContract, and CalendarContract. Never claims access to protected private directories.
 */
class MobileStorageScanner(private val context: Context) {

    private val documentExtensions = setOf(
        "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "csv"
    )

    suspend fun scanAllAccessibleCategories(
        userSelectedFolderUris: List<Uri> = emptyList()
    ): List<CategoryScanSummary> = withContext(Dispatchers.IO) {
        val results = mutableListOf<CategoryScanSummary>()

        // 1. Photos & 3. Screenshots
        val hasImagePerm = hasMediaPermission(BackupCategory.PHOTOS)
        if (hasImagePerm) {
            val allImages = queryMediaStoreImages()
            val (screenshots, photos) = allImages.partition { item ->
                item.relativePath.contains("Screenshot", ignoreCase = true) ||
                    item.displayName.contains("Screenshot", ignoreCase = true)
            }
            results.add(buildSummary(BackupCategory.PHOTOS, photos, true, null))
            results.add(buildSummary(BackupCategory.SCREENSHOTS, screenshots, true, null))
        } else {
            results.add(buildSummary(BackupCategory.PHOTOS, emptyList(), false, "Requires Photos/Media permission."))
            results.add(buildSummary(BackupCategory.SCREENSHOTS, emptyList(), false, "Requires Photos/Media permission."))
        }

        // 2. Videos
        val hasVideoPerm = hasMediaPermission(BackupCategory.VIDEOS)
        if (hasVideoPerm) {
            val videos = queryMediaStoreVideos()
            results.add(buildSummary(BackupCategory.VIDEOS, videos, true, null))
        } else {
            results.add(buildSummary(BackupCategory.VIDEOS, emptyList(), false, "Requires Video permission."))
        }

        // 4. Audio & 5. Voice Recordings
        val hasAudioPerm = hasMediaPermission(BackupCategory.AUDIO)
        if (hasAudioPerm) {
            val allAudio = queryMediaStoreAudio()
            val (recordings, music) = allAudio.partition { item ->
                item.relativePath.contains("Record", ignoreCase = true) ||
                    item.relativePath.contains("Voice", ignoreCase = true)
            }
            results.add(buildSummary(BackupCategory.AUDIO, music, true, null))
            results.add(
                buildSummary(
                    BackupCategory.VOICE_RECORDINGS,
                    recordings,
                    true,
                    "Scans accessible shared Recording/Voice folders only."
                )
            )
        } else {
            results.add(buildSummary(BackupCategory.AUDIO, emptyList(), false, "Requires Audio permission."))
            results.add(buildSummary(BackupCategory.VOICE_RECORDINGS, emptyList(), false, "Requires Audio permission."))
        }

        // 6. Documents, 7. Downloads, 8. Other Files
        val filesCollection = queryGeneralFiles()
        val docs = mutableListOf<ScannedFileItem>()
        val downloads = mutableListOf<ScannedFileItem>()
        val others = mutableListOf<ScannedFileItem>()

        for (item in filesCollection) {
            val ext = item.displayName.substringAfterLast('.', "").lowercase()
            when {
                item.relativePath.startsWith("Download", ignoreCase = true) -> {
                    downloads.add(item.copy(category = BackupCategory.DOWNLOADS))
                }
                ext in documentExtensions -> {
                    docs.add(item.copy(category = BackupCategory.DOCUMENTS))
                }
                else -> {
                    others.add(item.copy(category = BackupCategory.OTHER_FILES))
                }
            }
        }
        results.add(buildSummary(BackupCategory.DOCUMENTS, docs, true, "Includes accessible PDF, Office, TXT, and CSV files."))
        results.add(buildSummary(BackupCategory.DOWNLOADS, downloads, true, null))
        results.add(buildSummary(BackupCategory.OTHER_FILES, others, true, "Non-media files in shared storage."))

        // 9. User-Selected SAF Folders
        val safFiles = mutableListOf<ScannedFileItem>()
        userSelectedFolderUris.forEach { treeUri ->
            DocumentFile.fromTreeUri(context, treeUri)?.let { rootDoc ->
                traverseDocumentTree(rootDoc, rootDoc.name ?: "SelectedFolder", safFiles)
            }
        }
        results.add(
            buildSummary(
                BackupCategory.USER_FOLDERS,
                safFiles,
                true,
                if (userSelectedFolderUris.isEmpty()) "Use 'Add Folder' via Storage Access Framework to include custom directories." else null
            )
        )

        // 10. Contacts
        val hasContactsPerm = ContextCompat.checkSelfPermission(
            context, android.Manifest.permission.READ_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED
        val contactCount = if (hasContactsPerm) countContacts() else 0
        results.add(
            CategoryScanSummary(
                category = BackupCategory.CONTACTS,
                totalItemCount = contactCount,
                totalSizeBytes = contactCount * 512L,
                estimatedBackupSizeBytes = contactCount * 380L,
                lastModifiedMillis = System.currentTimeMillis(),
                isSelected = hasContactsPerm && contactCount > 0,
                status = if (hasContactsPerm) CategoryBackupStatus.READY else CategoryBackupStatus.PERMISSION_LIMITED,
                permissionGranted = hasContactsPerm,
                limitationNote = if (hasContactsPerm) "Exports to standard vCard 3.0 (Contacts.vcf)." else "Grant Contacts permission to export vCard backup."
            )
        )

        // 11. Calendar Events
        val hasCalendarPerm = ContextCompat.checkSelfPermission(
            context, android.Manifest.permission.READ_CALENDAR
        ) == PackageManager.PERMISSION_GRANTED
        val calendarCount = if (hasCalendarPerm) countCalendarEvents() else 0
        results.add(
            CategoryScanSummary(
                category = BackupCategory.CALENDAR,
                totalItemCount = calendarCount,
                totalSizeBytes = calendarCount * 640L,
                estimatedBackupSizeBytes = calendarCount * 450L,
                lastModifiedMillis = System.currentTimeMillis(),
                isSelected = hasCalendarPerm && calendarCount > 0,
                status = if (hasCalendarPerm) CategoryBackupStatus.READY else CategoryBackupStatus.PERMISSION_LIMITED,
                permissionGranted = hasCalendarPerm,
                limitationNote = if (hasCalendarPerm) "Exports to iCalendar RFC 5545 (Calendar.ics)." else "Grant Calendar permission to export events."
            )
        )

        // 12. Optional SMS/MMS & Call History (Policy & Role Gated)
        results.add(
            CategoryScanSummary(
                category = BackupCategory.SMS_CALL_LOGS,
                totalItemCount = 0,
                totalSizeBytes = 0L,
                estimatedBackupSizeBytes = 0L,
                lastModifiedMillis = null,
                isSelected = false,
                status = CategoryBackupStatus.PERMISSION_LIMITED,
                permissionGranted = false,
                limitationNote = "Restricted by Android role & Google Play policy unless granted SMS/Call Log permission in eligible distributions."
            )
        )

        results
    }

    private fun buildSummary(
        category: BackupCategory,
        items: List<ScannedFileItem>,
        permissionGranted: Boolean,
        note: String?
    ): CategoryScanSummary {
        val totalBytes = items.sumOf { it.sizeBytes }
        val compressionRatio = when (category) {
            BackupCategory.PHOTOS, BackupCategory.VIDEOS, BackupCategory.AUDIO -> 0.98
            else -> 0.72
        }
        val lastMod = items.maxOfOrNull { it.lastModifiedEpochMillis }
        return CategoryScanSummary(
            category = category,
            totalItemCount = items.size,
            totalSizeBytes = totalBytes,
            estimatedBackupSizeBytes = (totalBytes * compressionRatio).toLong(),
            lastModifiedMillis = lastMod,
            isSelected = permissionGranted && items.isNotEmpty(),
            status = when {
                !permissionGranted -> CategoryBackupStatus.PERMISSION_LIMITED
                items.isEmpty() -> CategoryBackupStatus.NOT_BACKED_UP
                else -> CategoryBackupStatus.READY
            },
            permissionGranted = permissionGranted,
            limitationNote = note,
            files = items
        )
    }

    private fun hasMediaPermission(category: BackupCategory): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val perm = when (category) {
                BackupCategory.PHOTOS, BackupCategory.SCREENSHOTS -> android.Manifest.permission.READ_MEDIA_IMAGES
                BackupCategory.VIDEOS -> android.Manifest.permission.READ_MEDIA_VIDEO
                BackupCategory.AUDIO, BackupCategory.VOICE_RECORDINGS -> android.Manifest.permission.READ_MEDIA_AUDIO
                else -> android.Manifest.permission.READ_MEDIA_IMAGES
            }
            ContextCompat.checkSelfPermission(context, perm) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(
                context, android.Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun queryMediaStoreImages(): List<ScannedFileItem> {
        return queryMediaUri(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            BackupCategory.PHOTOS
        )
    }

    private fun queryMediaStoreVideos(): List<ScannedFileItem> {
        return queryMediaUri(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            BackupCategory.VIDEOS
        )
    }

    private fun queryMediaStoreAudio(): List<ScannedFileItem> {
        return queryMediaUri(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            BackupCategory.AUDIO
        )
    }

    private fun queryGeneralFiles(): List<ScannedFileItem> {
        val uri = MediaStore.Files.getContentUri("external")
        val selection = "${MediaStore.Files.FileColumns.MEDIA_TYPE} = ?"
        val selectionArgs = arrayOf(MediaStore.Files.FileColumns.MEDIA_TYPE_NONE.toString())
        return queryMediaUri(uri, BackupCategory.DOCUMENTS, selection, selectionArgs)
    }

    private fun queryMediaUri(
        collectionUri: Uri,
        defaultCategory: BackupCategory,
        selection: String? = null,
        selectionArgs: Array<String>? = null
    ): List<ScannedFileItem> {
        val items = mutableListOf<ScannedFileItem>()
        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.RELATIVE_PATH,
            MediaStore.MediaColumns.MIME_TYPE,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_MODIFIED
        )
        runCatching {
            context.contentResolver.query(
                collectionUri,
                projection,
                selection,
                selectionArgs,
                "${MediaStore.MediaColumns.DATE_MODIFIED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val relPathCol = cursor.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH)
                val mimeCol = cursor.getColumnIndex(MediaStore.MediaColumns.MIME_TYPE)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
                val modCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val name = cursor.getString(nameCol) ?: "file_$id"
                    val relDir = if (relPathCol >= 0) cursor.getString(relPathCol) ?: "" else ""
                    val mime = if (mimeCol >= 0) cursor.getString(mimeCol) ?: "application/octet-stream" else "application/octet-stream"
                    val size = cursor.getLong(sizeCol)
                    val modifiedSec = cursor.getLong(modCol)
                    if (size <= 0L) continue

                    val contentUri = ContentUris.withAppendedId(collectionUri, id)
                    val fullRelativePath = if (relDir.isNotEmpty()) "$relDir$name" else name
                    items.add(
                        ScannedFileItem(
                            id = "${defaultCategory.id}_$id",
                            contentUriString = contentUri.toString(),
                            displayName = name,
                            relativePath = fullRelativePath,
                            mimeType = mime,
                            sizeBytes = size,
                            lastModifiedEpochMillis = modifiedSec * 1000L,
                            category = defaultCategory
                        )
                    )
                }
            }
        }
        return items
    }

    private fun traverseDocumentTree(
        dir: DocumentFile,
        prefix: String,
        target: MutableList<ScannedFileItem>
    ) {
        dir.listFiles().forEach { doc ->
            val name = doc.name ?: return@forEach
            val relPath = "$prefix/$name"
            if (doc.isDirectory) {
                traverseDocumentTree(doc, relPath, target)
            } else if (doc.isFile && doc.canRead()) {
                target.add(
                    ScannedFileItem(
                        id = doc.uri.toString(),
                        contentUriString = doc.uri.toString(),
                        displayName = name,
                        relativePath = relPath,
                        mimeType = doc.type ?: "application/octet-stream",
                        sizeBytes = doc.length(),
                        lastModifiedEpochMillis = doc.lastModified(),
                        category = BackupCategory.USER_FOLDERS
                    )
                )
            }
        }
    }

    private fun countContacts(): Int {
        var count = 0
        runCatching {
            context.contentResolver.query(
                ContactsContract.Contacts.CONTENT_URI,
                arrayOf(ContactsContract.Contacts._ID),
                null, null, null
            )?.use { count = it.count }
        }
        return count
    }

    private fun countCalendarEvents(): Int {
        var count = 0
        runCatching {
            context.contentResolver.query(
                CalendarContract.Events.CONTENT_URI,
                arrayOf(CalendarContract.Events._ID),
                null, null, null
            )?.use { count = it.count }
        }
        return count
    }
}
