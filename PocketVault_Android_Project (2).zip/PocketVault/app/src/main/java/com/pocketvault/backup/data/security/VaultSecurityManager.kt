package com.pocketvault.backup.data.security

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.MessageDigest
import java.security.SecureRandom

class VaultSecurityManager(context: Context) {

    private val masterKey: MasterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val encryptedPrefs: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "pocketvault_secure_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    var connectedAccountEmail: String?
        get() = encryptedPrefs.getString(KEY_ACCOUNT_EMAIL, null)
        set(value) = encryptedPrefs.edit().putString(KEY_ACCOUNT_EMAIL, value).apply()

    var driveRootFolderId: String?
        get() = encryptedPrefs.getString(KEY_DRIVE_ROOT_FOLDER_ID, null)
        set(value) = encryptedPrefs.edit().putString(KEY_DRIVE_ROOT_FOLDER_ID, value).apply()

    var biometricAppLockEnabled: Boolean
        get() = encryptedPrefs.getBoolean(KEY_BIOMETRIC_LOCK, false)
        set(value) = encryptedPrefs.edit().putBoolean(KEY_BIOMETRIC_LOCK, value).apply()

    var preferredLanguageCode: String
        get() = encryptedPrefs.getString(KEY_LANGUAGE, "en") ?: "en"
        set(value) = encryptedPrefs.edit().putString(KEY_LANGUAGE, value).apply()

    fun isStrongPassword(password: CharArray): Boolean {
        if (password.size < 8) return false
        return password.any { it.isLetter() } && password.any { it.isDigit() }
    }

    fun savePasswordVerificationHash(password: CharArray) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val hash = hashWithSalt(password, salt)
        encryptedPrefs.edit()
            .putString(KEY_PWD_SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString(KEY_PWD_VERIFIER, Base64.encodeToString(hash, Base64.NO_WRAP))
            .apply()
    }

    fun verifyPasswordAgainstLocalVerifier(password: CharArray): Boolean {
        val saltB64 = encryptedPrefs.getString(KEY_PWD_SALT, null) ?: return true
        val verifierB64 = encryptedPrefs.getString(KEY_PWD_VERIFIER, null) ?: return true
        val salt = Base64.decode(saltB64, Base64.NO_WRAP)
        val expected = Base64.decode(verifierB64, Base64.NO_WRAP)
        val actual = hashWithSalt(password, salt)
        return MessageDigest.isEqual(expected, actual)
    }

    fun clearAccountSessionKeepLocalHistory() {
        encryptedPrefs.edit()
            .remove(KEY_ACCOUNT_EMAIL)
            .remove(KEY_DRIVE_ROOT_FOLDER_ID)
            .apply()
    }

    private fun hashWithSalt(password: CharArray, salt: ByteArray): ByteArray {
        val digest = MessageDigest.getInstance("SHA-256")
        digest.update(salt)
        digest.update(password.concatToString().toByteArray(Charsets.UTF_8))
        return digest.digest()
    }

    companion object {
        private const val KEY_ACCOUNT_EMAIL = "connected_account_email"
        private const val KEY_DRIVE_ROOT_FOLDER_ID = "drive_root_folder_id"
        private const val KEY_BIOMETRIC_LOCK = "biometric_app_lock"
        private const val KEY_LANGUAGE = "preferred_language"
        private const val KEY_PWD_SALT = "pwd_verifier_salt"
        private const val KEY_PWD_VERIFIER = "pwd_verifier_hash"
    }
}
