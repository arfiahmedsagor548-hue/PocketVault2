package com.pocketvault.backup.data.local

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "backup_snapshots")
data class BackupSnapshotEntity(
    @PrimaryKey val backupId: String,
    val deviceLabel: String,
    val createdAtEpochMillis: Long,
    val createdAtFormatted: String,
    val categoriesCsv: String,
    val totalFilesCount: Int,
    val totalArchiveSizeBytes: Long,
    val driveFolderId: String,
    val manifestDriveFileId: String,
    val encryptedAes256: Boolean,
    val verificationStatus: String,
    val manifestJson: String,
    val reportHtmlPath: String?
)

@Entity(tableName = "incremental_file_cache", primaryKeys = ["relativePath", "categoryId"])
data class IncrementalFileCacheEntity(
    val relativePath: String,
    val categoryId: String,
    val sizeBytes: Long,
    val lastModifiedEpochMillis: Long,
    val sha256Checksum: String,
    val lastBackupId: String
)

@Entity(tableName = "operation_logs")
data class OperationLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestampMillis: Long,
    val operationType: String,
    val severity: String,
    val title: String,
    val details: String,
    val suggestedAction: String
)

@Dao
interface PocketVaultDao {
    @Query("SELECT * FROM backup_snapshots ORDER BY createdAtEpochMillis DESC")
    fun observeSnapshots(): Flow<List<BackupSnapshotEntity>>

    @Query("SELECT * FROM backup_snapshots ORDER BY createdAtEpochMillis DESC")
    suspend fun getAllSnapshots(): List<BackupSnapshotEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSnapshot(snapshot: BackupSnapshotEntity)

    @Query("SELECT * FROM incremental_file_cache WHERE relativePath = :path AND categoryId = :categoryId LIMIT 1")
    suspend fun getCachedFileEntry(path: String, categoryId: String): IncrementalFileCacheEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCachedFiles(entries: List<IncrementalFileCacheEntity>)

    @Query("SELECT * FROM operation_logs ORDER BY timestampMillis DESC LIMIT 200")
    fun observeLogs(): Flow<List<OperationLogEntity>>

    @Insert
    suspend fun insertLog(log: OperationLogEntity)
}

@Database(
    entities = [
        BackupSnapshotEntity::class,
        IncrementalFileCacheEntity::class,
        OperationLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class PocketVaultDatabase : RoomDatabase() {
    abstract fun dao(): PocketVaultDao

    companion object {
        @Volatile
        private var INSTANCE: PocketVaultDatabase? = null

        fun getInstance(context: Context): PocketVaultDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    PocketVaultDatabase::class.java,
                    "pocketvault_metadata.db"
                ).fallbackToDestructiveMigration().build().also { INSTANCE = it }
            }
        }
    }
}
